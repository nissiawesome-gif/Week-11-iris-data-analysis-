# Week 11: Data Analysis — Iris Dataset

## Overview
This project performs exploratory data analysis (EDA) on the Iris dataset using Python. It prints dataset information and summary statistics, checks for missing values, and creates visualizations.

## Project structure
```text
week-11-iris-data-analysis/
├── Iris.csv
├── iris_analysis.py
├── README.md
├── requirements.txt
└── plots/
```

## Requirements
- Python 3
- pandas
- matplotlib
- seaborn

Install dependencies:
```bash
pip install -r requirements.txt
```

## How to run
1. Keep `Iris.csv` in the same folder as `iris_analysis.py`.
2. Open a terminal in the project folder.
3. Run:
   ```bash
   python iris_analysis.py
   ```

The script prints the first five rows, dataset dimensions, column information, missing-value counts, and summary statistics. It saves applicable charts in the `plots/` folder.

## Visualizations
- Histograms: feature distributions
- Scatter plot: relationship between two numerical features
- Box plot: feature comparison across species/classes, when a category column is available
- Correlation heatmap: correlations between numerical features

## Conclusion
Exploratory data analysis helps reveal the structure, distribution, and relationships in a dataset. The generated statistics and plots provide an initial understanding of the Iris data.

## Dataset note
This script attempts to recognize common Iris column names and also works with other numeric column names. Ensure `Iris.csv` is included before running the script.
