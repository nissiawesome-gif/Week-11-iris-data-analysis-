"""
Week 11: Data Analysis — Iris Dataset
Run with: python iris_analysis.py
"""

from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

PROJECT_DIR = Path(__file__).resolve().parent
DATA_PATH = PROJECT_DIR / "Iris.csv"
PLOTS_DIR = PROJECT_DIR / "plots"
PLOTS_DIR.mkdir(exist_ok=True)

# Load the dataset
df = pd.read_csv(DATA_PATH)

print("\n--- First five rows ---")
print(df.head())

print("\n--- Dataset shape (rows, columns) ---")
print(df.shape)

print("\n--- Dataset information ---")
df.info()

print("\n--- Missing values per column ---")
print(df.isnull().sum())

print("\n--- Summary statistics ---")
print(df.describe(include="all"))

# Select numeric columns and remove a possible ID column from charts.
numeric_df = df.select_dtypes(include="number")
plot_numeric = numeric_df.drop(
    columns=[c for c in numeric_df.columns if c.lower() in {"id", "unnamed: 0"}],
    errors="ignore"
)

# Histograms
if not plot_numeric.empty:
    plot_numeric.hist(figsize=(10, 8), edgecolor="black")
    plt.suptitle("Distributions of Iris Dataset Features")
    plt.tight_layout()
    plt.savefig(PLOTS_DIR / "histograms.png", dpi=150, bbox_inches="tight")
    plt.close()

# Find the species/category column in common Iris CSV formats.
species_candidates = [c for c in df.columns if c.lower() in {"species", "variety", "class"}]
species_col = species_candidates[0] if species_candidates else None

# Scatter plot: use known Iris column names if present, otherwise use first two numeric columns.
numeric_cols = list(plot_numeric.columns)
x_col = next((c for c in numeric_cols if c.lower() in {"sepallengthcm", "sepal length", "sepallength"}), None)
y_col = next((c for c in numeric_cols if c.lower() in {"petallengthcm", "petal length", "petallength"}), None)
if x_col is None and len(numeric_cols) >= 1:
    x_col = numeric_cols[0]
if y_col is None and len(numeric_cols) >= 2:
    y_col = numeric_cols[2] if len(numeric_cols) >= 3 else numeric_cols[1]

if x_col and y_col:
    plt.figure(figsize=(8, 6))
    sns.scatterplot(data=df, x=x_col, y=y_col, hue=species_col if species_col else None)
    plt.title(f"{x_col} vs {y_col}")
    plt.tight_layout()
    plt.savefig(PLOTS_DIR / "scatter_plot.png", dpi=150, bbox_inches="tight")
    plt.close()

# Box plot by species/category when available.
petal_length_col = next((c for c in numeric_cols if c.lower() in {"petallengthcm", "petal length", "petallength"}), None)
box_col = petal_length_col or (numeric_cols[0] if numeric_cols else None)
if species_col and box_col:
    plt.figure(figsize=(8, 6))
    sns.boxplot(data=df, x=species_col, y=box_col)
    plt.title(f"{box_col} by {species_col}")
    plt.xticks(rotation=15)
    plt.tight_layout()
    plt.savefig(PLOTS_DIR / "box_plot.png", dpi=150, bbox_inches="tight")
    plt.close()

# Correlation heatmap
if len(plot_numeric.columns) >= 2:
    plt.figure(figsize=(8, 6))
    sns.heatmap(plot_numeric.corr(), annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(PLOTS_DIR / "correlation_heatmap.png", dpi=150, bbox_inches="tight")
    plt.close()

print(f"\nCharts (where applicable) have been saved to: {PLOTS_DIR}")
print("\nAnalysis complete.")
